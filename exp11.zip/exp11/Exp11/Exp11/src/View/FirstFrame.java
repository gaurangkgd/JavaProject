package View;

import javax.swing.*;
import java.awt.*;

public class FirstFrame extends JFrame {
    JButton manageTouristBtn;
    JButton manageCityBtn;
    JButton manageEnrollBtn;
    JPanel firstPanel;


    FirstFrame()
    {
        super("Main DashBoard");
        manageTouristBtn = new JButton("Manage Tourist");
        manageCityBtn = new JButton("Manage City");
        manageEnrollBtn = new JButton("Manage Enrollment");

        firstPanel = new JPanel();
        firstPanel.setLayout(new GridLayout(3,1,20,20));
        firstPanel.add(manageTouristBtn);
        firstPanel.add(manageCityBtn);
        firstPanel.add(manageEnrollBtn);

        add(firstPanel);

        pack();
        setSize(500, 600);
        setVisible(true);
    }

    public void setFirstPanel(JPanel firstPanel) {
        this.firstPanel = firstPanel;
    }

    public void setManageTouristBtn(JButton manageTouristBtn) {
        this.manageTouristBtn = manageTouristBtn;
    }

    public void setManageCityBtn(JButton manageCityBtn) {
        this.manageCityBtn = manageCityBtn;
    }

    public void setManageEnrollBtn(JButton manageEnrollmentBtn) {
        this.manageEnrollBtn = manageEnrollBtn;
    }

    public JPanel getFirstPanel() {
        return firstPanel;
    }

    public JButton getManageTouristBtn() {
        return manageTouristBtn;
    }

    public JButton getManageCityBtn() {
        return manageCityBtn;
    }

    public JButton getManageEnrollBtn() {
        return manageEnrollBtn;
    }
}
