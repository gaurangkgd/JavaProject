/*
/**
* 
* 
* Identification comments:
*   Name: Sarthak Shinde
*   Homework/Lab 3B Assignment - Interfaces and Arrays
*   Due Date: 03-03-23
*   Email Address: sps6944@psu.edu
*   @version 1.0
*   
* 
* Beginning comments
* Filename: View.java
* author:   Sarthak Shinde
* Overview: The View class represents the user interface of an application, and it is responsible for presenting data to the 
            user and receiving input from them. It is typically used in the Model-View-Controller (MVC) architectural pattern, 
            where the View is the part of the application that interacts with the user and displays information. The public class 
            View is declared but there are no methods or fields defined in it.
*/

package View;

import View.Cities.ManageCitiesFrame;
import View.Enroll.ManageEnrollFrame;

import java.awt.*;
import java.util.ArrayList;

public class View {
    FirstFrame ff;
    ManageTouristFrame mtf;
    ManageCitiesFrame mcf;
    ManageEnrollFrame mef;


    public View() {
        ff = new FirstFrame();
        mtf = new ManageTouristFrame();
        mcf = new ManageCitiesFrame();
        mef = new ManageEnrollFrame();
    }

    public void centerInitialSetupTourist(int linesBeingDisplayed, int size) {
        mtf.getTourist_ip().getCpt().setLayout(new GridLayout(linesBeingDisplayed + 1, size));
        mtf.getTourist_ip().getCpt().createButtons((linesBeingDisplayed + 1) * size);
    }
    public void centerInitialSetupEnroll(int linesBeingDisplayed, int size) {
        mef.getEnroll_ip().getEtp().setLayout(new GridLayout(linesBeingDisplayed + 1, size));
        mef.getEnroll_ip().getEtp().createButtons((linesBeingDisplayed + 1) * size);
    }

    public void centerInitialSetupCity(int linesBeingDisplayed, int size) {
        mcf.getCity_ip().getCtp().setLayout(new GridLayout(linesBeingDisplayed + 1, size));
        mcf.getCity_ip().getCtp().createButtons((linesBeingDisplayed + 1) * size);
    }

    public void centerUpdateCity(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++) {
            mcf.getCity_ip().getCtp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int course_row_no = 0; course_row_no < lines.size(); course_row_no++) {
            for (int course_col_no = 0; course_col_no < headers.size(); course_col_no++) {
                int button_no = course_row_no * headers.size() + headers.size() + course_col_no;
                String button_txt = lines.get(course_row_no).get(course_col_no);

                mcf.getCity_ip().getCtp().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }

    public void centerUpdateTourist(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++) {
            mtf.getTourist_ip().getCpt().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int course_row_no = 0; course_row_no < lines.size(); course_row_no++) {
            for (int course_col_no = 0; course_col_no < headers.size(); course_col_no++) {
                int button_no = course_row_no * headers.size() + headers.size() + course_col_no;
                String button_txt = lines.get(course_row_no).get(course_col_no);

                mtf.getTourist_ip().getCpt().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }

    public void centerUpdateEnroll(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++) {
            mef.getEnroll_ip().getEtp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int enroll_row_no = 0; enroll_row_no < lines.size(); enroll_row_no++) {
            for (int enroll_col_no = 0; enroll_col_no < headers.size(); enroll_col_no++) {
                int button_no = enroll_row_no * headers.size() + headers.size() + enroll_col_no;
                String button_txt = lines.get(enroll_row_no).get(enroll_col_no);

                mef.getEnroll_ip().getEtp().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }

    public void setFf(FirstFrame ff) {
        this.ff = ff;
    }

    public FirstFrame getFf() {
        return ff;
    }

     public void setMtf(ManageTouristFrame mtf) {
     this.mtf = mtf;
    }

      public ManageTouristFrame getMtf() {
     return mtf;
 }

    public void setMcf(ManageCitiesFrame mcf) {
        this.mcf = mcf;
    }

    public ManageCitiesFrame getMcf() {
        return mcf;
    }

    public void setMef(ManageEnrollFrame mef) {
        this.mef = mef;
    }

    public ManageEnrollFrame getMef() {
        return mef;
    }

}

