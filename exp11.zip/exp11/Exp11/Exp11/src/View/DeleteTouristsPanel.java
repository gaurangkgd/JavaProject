package View;

import javax.swing.*;

public class DeleteTouristsPanel extends JPanel {

    JTextField txt_del_tourist_id;
    JButton deleteTouristBtn;

    public DeleteTouristsPanel()
    {

        txt_del_tourist_id = new JTextField();
        deleteTouristBtn = new JButton("Delete Tourist");

        txt_del_tourist_id.setText("txt_tourist_id");

        add(txt_del_tourist_id);
        add(deleteTouristBtn);
    }

    public JButton getDeleteTouristBtn() {
        return deleteTouristBtn;
    }

    public JTextField getTxt_del_tourist_id() {
        return txt_del_tourist_id;
    }

    public void setDeleteTouristBtn(JButton deleteTouristBtn) {
        this.deleteTouristBtn = deleteTouristBtn;
    }

    public void setTxt_del_tourist_id(JTextField txt_del_tourist_id) {
        this.txt_del_tourist_id = txt_del_tourist_id;
    }
}
